# Joseph's stuff [![Licence](https://img.shields.io/badge/license-MIT-yellow.svg)](https://github.com/arcade-master/arcade-master.github.io/blob/master/LICENSE)  [![Discord](https://discordapp.com/api/guilds/524047249408393216/widget.png)](https://discord.gg/BF3ua9q)
My little [website](https://arcade-master.github.io/). Made by me. Hosted by Github <3

Code and graphics copyright Orteil, 2013-2018
